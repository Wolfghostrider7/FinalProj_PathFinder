﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dropDestroyer : MonoBehaviour
{

    public GameObject RainDrop;
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Hazard")
        {
            Destroy(this.gameObject);
        }
        if (other.tag == "Ground")
        {
            Destroy(this.gameObject);
        }
    }
}
