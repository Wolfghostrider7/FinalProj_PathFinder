﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class BackgroundChanger : MonoBehaviour
{
    [SerializeField]
    Image back1;
    [SerializeField]
    Image back2;

    void Start()
    {

        back1.enabled = true;
        back2.enabled = false;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "Player")
        {
            back1.enabled = false;
            back2.enabled = true;
        }
    }
}
