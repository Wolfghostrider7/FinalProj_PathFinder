﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckpointAnimation : MonoBehaviour
{

    protected bool PlayerInRange;
    Animator anim;
    protected void Update()
    {
        if (PlayerInRange && Input.GetKeyDown(KeyCode.F))
        {
            anim.SetTrigger("Checked");
        }
    }

    protected void OnTriggerEnter(Collider otherCollider)
    {
        if (otherCollider.CompareTag("Player"))
        {
            PlayerInRange = true;
        }
    }

    protected void OnTriggerExit(Collider otherCollider)
    {
        if (otherCollider.CompareTag("Player"))
        {
            PlayerInRange = false;
        }
    }
}
